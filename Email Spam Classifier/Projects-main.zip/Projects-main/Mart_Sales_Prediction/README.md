# Mart Sales Prediction

Data set consists of list of items, price,item_visibility,establishment year,outlet type and so on.
Our aim is to find the sales of items in each outlet say for example- sales of each item in super market, in Grocery store,etc.
First we will visualize the data to understand better.
Plot graphs with each feature to find the correlation between them.

Handle missing datas,drop unwanted features,convert categorical data to numerical

Build the models using all the below algorithms:

Decision tree regressor,random forest regressor,ada boost regressor,svm,xgboost

Calculate the error for each algorithm.

XGBoost gives the model with high accuracy
