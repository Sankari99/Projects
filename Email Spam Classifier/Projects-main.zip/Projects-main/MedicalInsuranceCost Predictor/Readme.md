## Aim:To predict the Medical Insurance Cost
* The objective of this article is to accurately predict insurance costs based on people’s data, including age, Body Mass Index, smoking or not, etc. 
* Normalizing the features
* Performing EDA and determining what variables are
influencing insurance costs
* Model is built with R2score of 80% and deployed in
Streamlit
* Web app link:
https://rehavelu-medical-medical-insurance-cost-predictor-webapp-jrcdkf.streamlit.app/
